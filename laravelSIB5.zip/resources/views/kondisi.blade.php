<?php
$nama = 'BLU';
echo 'Hai ' . $nama;

?>

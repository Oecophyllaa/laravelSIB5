<script src="{{ asset('frontend/js/bootstrap.bundle.min.js') }}"></script>
<script src="{{ asset('frontend/js/tiny-slider.js') }}"></script>
<script src="{{ asset('frontend/js/custom.js') }}"></script>

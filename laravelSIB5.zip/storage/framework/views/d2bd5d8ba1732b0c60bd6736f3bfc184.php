<?php
  $nama = 'Budi';
  $nilai = 59.99;
?>

<?php if($nilai >= 60): ?>
  <?php $ket = "lulus"; ?>
<?php else: ?>
  <?php $ket = "Gagal"; ?>
<?php endif; ?>

Siswa <?php echo e($nama); ?> dengan nilai <?php echo e($nilai); ?> dinyatakan <?php echo e($ket); ?>

<?php /**PATH C:\laragon\www\laravelSIB5\resources\views/coba/nilai.blade.php ENDPATH**/ ?>
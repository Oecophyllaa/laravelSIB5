<nav class="custom-navbar navbar navbar navbar-expand-md navbar-dark bg-dark" arial-label="Furni navigation bar">

  <div class="container">
    <a class="navbar-brand" href="<?php echo e(route('front.index')); ?>">Furni<span>.</span></a>

    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarsFurni" aria-controls="navbarsFurni"
      aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarsFurni">
      <ul class="custom-navbar-nav navbar-nav ms-auto mb-2 mb-md-0">
        <li class="nav-item active">
          <a class="nav-link" href="<?php echo e(route('front.index')); ?>/#">Home</a>
        </li>
        <?php if(auth()->guard()->check()): ?>
          <li><a class="nav-link" href="<?php echo e(route('front.shop')); ?>">Shop</a></li>
        <?php endif; ?>
        <li><a class="nav-link" href="#">About us</a></li>
        <li><a class="nav-link" href="#">Services</a></li>
        <li><a class="nav-link" href="#">Blog</a></li>
        <li><a class="nav-link" href="#">Contact us</a></li>
      </ul>

      <ul class="custom-navbar-cta navbar-nav mb-2 mb-md-0 ms-5">
        <li><a class="nav-link" href="<?php echo e(route('login')); ?>"><img src="<?php echo e(asset('frontend/images/user.svg')); ?>"></a></li>
        <?php if(auth()->guard()->check()): ?>
          <!-- Logout -->
          <li class="nav-item dropdown">
            <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true"
              aria-expanded="false" v-pre>
              <?php echo e(Auth::user()->name); ?>

            </a>

            <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
              <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();document.getElementById('logout-form').submit();">
                <?php echo e(__('Logout')); ?>

              </a>

              <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                <?php echo csrf_field(); ?>
              </form>
            </div>
          </li>
          <!-- End Logout -->

          

          <!-- Cart Section -->
          <div class="dropdown">
            <button type="button" class="btn btn-info" data-toggle="dropdown">
              <i class="fa fa-shopping-cart" aria-hidden="true"></i> Cart <span
                class="badge badge-pill badge-danger"><?php echo e(count((array) session('cart'))); ?></span>
            </button>

            <div class="dropdown-menu">
              <div class="row total-header-section">
                <div class="col-lg-6 col-sm-6 col-6">
                  <i class="fa fa-shopping-cart" aria-hidden="true"></i> <span
                    class="badge badge-pill badge-danger"><?php echo e(count((array) session('cart'))); ?></span>
                </div>
                <?php $total = 0 ?>
                <?php $__currentLoopData = (array) session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php $total += $details['harga_jual'] * $details['quantity'] ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-6 col-sm-6 col-6 total-section text-right">
                  <p>Total: <span class="text-info"> Rp<?php echo e(number_format($total, 0, ',', '.')); ?> </span></p>
                </div>
              </div>
              <?php if(session('cart')): ?>
                <?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="row cart-detail">
                    <div class="col-lg-4 col-sm-4 col-4 cart-detail-img">
                      <?php if(empty($details['foto'])): ?>
                        <img src="<?php echo e(asset('backend/img/placeholder.jpg')); ?>" />
                      <?php else: ?>
                        <img src="<?php echo e(asset('backend/img/' . $details['foto'])); ?>" />
                      <?php endif; ?>
                    </div>

                    <div class="col-lg-8 col-sm-8 col-8 cart-detail-product">
                      <p><?php echo e($details['nama']); ?></p>
                      <span class="price text-info"> Rp<?php echo e(number_format($details['harga_jual'], 0, ',', '.')); ?></span>
                      <span class="count"> Quantity:<?php echo e($details['quantity']); ?> </span>
                    </div>
                  </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
              <div class="row">
                <div class="col-lg-12 col-sm-12 col-12 text-center checkout">
                  <a href="<?php echo e(route('cart')); ?>" class="btn btn-primary btn-block">View all</a>
                </div>
              </div>
            </div>
          </div>
          <!-- End Cart Section -->
        <?php endif; ?>

      </ul>
    </div>
  </div>

</nav>
<?php /**PATH C:\laragon\www\laravelSIB5\resources\views/includes/front/navbar.blade.php ENDPATH**/ ?>
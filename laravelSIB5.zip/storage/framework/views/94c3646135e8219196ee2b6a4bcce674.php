<h3>Data Mahasiswa</h3>

<ol>
  <li>Mahasiswa 1 : <?php echo e($mhs1); ?>, Asal : <?php echo e($asal1); ?></li>
  <li>Mahasiswa 2 : <?php echo e($mhs2); ?>, Asal : <?php echo e($asal2); ?></li>
</ol>
<?php /**PATH C:\laragon\www\laravelSIB5\resources\views/coba/data.blade.php ENDPATH**/ ?>
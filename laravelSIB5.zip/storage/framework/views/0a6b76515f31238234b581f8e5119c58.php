<script src="<?php echo e(asset('frontend/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/js/tiny-slider.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/js/custom.js')); ?>"></script>
<?php /**PATH C:\laragon\www\laravelSIB5\resources\views/includes/front/script.blade.php ENDPATH**/ ?>
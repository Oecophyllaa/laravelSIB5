

<?php $__env->startSection('title', 'Add Jenis'); ?>

<?php $__env->startSection('content'); ?>
  <div class="container-fluid">
    <form action="<?php echo e(url('admin/jenis-produk/store')); ?>" method="POST" enctype="multipart/form-data">
      <?php echo csrf_field(); ?>

      <div class="form-group row">
        <label for="nama" class="col-2 col-form-label">Nama Jenis</label>
        <div class="col-8">
          <div class="input-group">
            <div class="input-group-prepend">
              <div class="input-group-text">
                <i class="fa fa-address-card"></i>
              </div>
            </div>
            <input id="nama" name="nama" type="text" class="form-control" placeholder="Isi jenis produk" />
          </div>
        </div>
      </div>
      <div class="form-group row">
        <div class="offset-2 col-8">
          <button name="submit" type="submit" class="btn btn-primary">Submit</button>
        </div>
      </div>
    </form>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laravelSIB5\resources\views/pages/admin/jenis_produk/create.blade.php ENDPATH**/ ?>
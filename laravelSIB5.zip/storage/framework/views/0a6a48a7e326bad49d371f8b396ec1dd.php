

<?php $__env->startSection('title', 'Add Pelanggan'); ?>

<?php $__env->startSection('content'); ?>
  <div class="container-fluid">
    <form method="POST" action="<?php echo e(route('pelanggan.store')); ?>" enctype="multipart/form-data">
      <?php echo csrf_field(); ?>
      <div class="form-group row">
        <label for="kode" class="col-2 col-form-label text-right">Kode</label>
        <div class="col-8">
          <input type="text" id="kode" name="kode" class="form-control">
        </div>
      </div>
      <div class="form-group row">
        <label for="nama" class="col-2 col-form-label text-right">Nama</label>
        <div class="col-8">
          <input type="text" id="nama" name="nama" class="form-control">
        </div>
      </div>
      <div class="form-group row">
        <label class="col-2 text-right">Jenis Kelamin</label>
        <div class="col-8">
          <?php $__currentLoopData = $gender; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="custom-control custom-radio custom-control-inline">
              <input type="radio" name="jk" id="radio_<?php echo e($loop->iteration); ?>" class="custom-control-input" value="<?php echo e($g); ?>" />
              <label for="radio_<?php echo e($loop->iteration); ?>" class="custom-control-label"><?php echo e($g); ?></label>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
      <div class="form-group row">
        <label for="text2" class="col-2 col-form-label text-right">Tempat Lahir</label>
        <div class="col-8">
          <input type="text" id="text2" name="tmp_lahir" class="form-control">
        </div>
      </div>
      <div class="form-group row">
        <label for="text3" class="col-2 col-form-label text-right">Tanggal Lahir</label>
        <div class="col-8">
          <input type="date" id="text3" name="tgl_lahir" class="form-control">
        </div>
      </div>
      <div class="form-group row">
        <label for="text4" class="col-2 col-form-label text-right">Email</label>
        <div class="col-8">
          <input type="text" id="text4" name="email" class="form-control">
        </div>
      </div>
      <div class="form-group row">
        <label for="select" class="col-2 col-form-label text-right">Kartu</label>
        <div class="col-8">
          <select id="select" name="kartu_id" class="custom-select">
            <?php $__currentLoopData = $kartu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($k->id); ?>"><?php echo e($k->nama); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>
      </div>
      <div class="form-group row">
        <div class="offset-2 col-8">
          <button name="submit" type="submit" class="btn btn-primary">Submit</button>
        </div>
      </div>
    </form>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laravelSIB5\resources\views/pages/admin/pelanggan/create.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Produk'); ?>

<?php $__env->startSection('content'); ?>
  <div class="container-fluid">

    <!-- Page Heading -->
    <!-- <h1 class="h3 mb-2 text-gray-800">DataTabel Produk</h1> -->
    <p class="mb-4"><a href="<?php echo e(route('dashboard.index')); ?>">Dashboard</a> &LongRightArrow; Produk</p>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
      <div class="card-header py-3">
        <!-- Create Produk -->
        <a href="<?php echo e(url('admin/produk/create')); ?>" class="btn btn-primary">
          <i class="fas fa-plus"></i>
        </a>
        <!-- PDF -->
        <a href="<?php echo e(route('produk.stream.pdf')); ?>" target="_blank" class="btn btn-danger">
          <i class="fas fa-file-pdf"></i>
        </a>
        <!-- EXCEL -->
        <a href="<?php echo e(route('produk.download.excel')); ?>" target="_blank" class="btn btn-success">
          <i class="fas fa-file-excel"></i>
        </a><!-- Export -->

        <button type="button" class="btn btn-info" data-toggle="modal" data-target="#importModal">
          <i class="fas fa-upload"></i>
        </button>
        <div class="modal fade" id="importModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Import</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>

              <div class="modal-body">
                <form action="<?php echo e(route('produk.import.excel')); ?>" method="POST" id="import-form" enctype="multipart/form-data">
                  <?php echo csrf_field(); ?>

                  <div class="form-group">
                    <input type="file" name="file" />
                  </div>

                </form>
              </div>

              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-info" onclick="event.preventDefault();document.getElementById('import-form').submit();">
                  Import
                </button>
              </div>
            </div>
          </div>
        </div>

      </div>

      <div class="card-body">
        <div class="table-responsive">
          <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
            <thead>
              <tr>
                <th>No</th>
                <th>Kode</th>
                <th>Nama</th>
                <th>Harga Beli</th>
                <th>Harga Jual</th>
                <th>Stok</th>
                <th>Minimal Stok</th>
                <th>Jenis Produk</th>
                <th>Action</th>
              </tr>
            </thead>

            <tfoot>
              <tr>
                <th>No</th>
                <th>Kode</th>
                <th>Nama</th>
                <th>Harga Beli</th>
                <th>Harga Jual</th>
                <th>Stok</th>
                <th>Minimal Stok</th>
                <th>Jenis Produk</th>
                <th>Action</th>
              </tr>
            </tfoot>

            <tbody>
              <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($loop->iteration); ?></td>
                  <td><?php echo e($pr->kode); ?></td>
                  <td><?php echo e($pr->nama); ?></td>
                  <td><?php echo e($pr->harga_beli); ?></td>
                  <td><?php echo e($pr->harga_jual); ?></td>
                  <td><?php echo e($pr->stok); ?></td>
                  <td><?php echo e($pr->min_stok); ?></td>
                  <td><?php echo e($pr->jenis); ?></td>
                  <td>
                    <a href="<?php echo e(url('admin/produk/show/' . $pr->id)); ?>" class="btn btn-sm btn-info"><i class="fas fa-eye"></i></a>
                    <a href="<?php echo e(route('produk.detail.stream.pdf', $pr->id)); ?>" class="btn btn-sm btn-success"><i class="fas fa-file-pdf"></i></a>
                    <a href="<?php echo e(url('admin/produk/edit/' . $pr->id)); ?>" class="btn btn-sm btn-warning"><i class="fas fa-edit"></i></a>

                    <!-- Delete Modal Button -->
                    <button type="button" class="btn btn-sm btn-danger" data-toggle="modal" data-target="#exampleModal<?php echo e($pr->id); ?>">
                      <i class="fas fa-trash"></i>
                    </button>

                    <!-- Delete Modal Box -->
                    <div class="modal fade" id="exampleModal<?php echo e($pr->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                      aria-hidden="true">
                      <div class="modal-dialog" role="document">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Hapus Data</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                            </button>
                          </div>
                          <div class="modal-body">
                            Apakah anda yakin akan menghapus data <strong><?php echo e($pr->nama); ?></strong> ?
                          </div>
                          <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <a href="<?php echo e(url('admin/produk/delete/' . $pr->id)); ?>" type="button" class="btn btn-danger">Delete</a>
                          </div>
                        </div>
                      </div>
                    </div>

                  </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>

          </table>
        </div>
      </div>
    </div>

  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-script'); ?>
  <!-- Page level custom scripts -->
  <script src="<?php echo e(asset('backend/js/demo/datatables-demo.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laravelSIB5\resources\views/pages/admin/produk/index.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Data Produk</title>
</head>

<body>
  <h3 align="center">Data Produk</h3>
  <table border="1" cellpadding="10" cellspacing="0">
    <thead>
      <tr>
        <th>No</th>
        <th>Kode</th>
        <th>Nama</th>
        <th>Harga Beli</th>
        <th>Harga Jual</th>
        <th>Stok</th>
        <th>Minimal Stok</th>
        <th>Jenis Produk</th>
      </tr>
    </thead>

    <tbody>
      <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($loop->iteration); ?></td>
          <td><?php echo e($prd->kode); ?></td>
          <td><?php echo e($prd->nama); ?></td>
          <td><?php echo e($prd->harga_beli); ?></td>
          <td><?php echo e($prd->harga_jual); ?></td>
          <td align="center"><?php echo e($prd->stok); ?></td>
          <td align="center"><?php echo e($prd->min_stok); ?></td>
          <td><?php echo e($prd->jenis); ?></td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</body>

</html>
<?php /**PATH C:\laragon\www\laravelSIB5\resources\views/pages/admin/produk/pdf2.blade.php ENDPATH**/ ?>
<?php
$nama = 'BLU';
echo 'Hai ' . $nama;

?>
<?php /**PATH C:\laragon\www\laravelSIB5\resources\views/kondisi.blade.php ENDPATH**/ ?>